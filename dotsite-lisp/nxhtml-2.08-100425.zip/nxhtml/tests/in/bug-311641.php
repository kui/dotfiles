<?

try {
} catch (PDOException $e) {
  }

?>