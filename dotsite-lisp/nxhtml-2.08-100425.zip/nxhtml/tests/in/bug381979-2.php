<?php
$a = array(
 'foo' => 'bar',
 'gaz' => 'gazonk',
);
?>