bteq << 'SQL part' | grep '\\$'| read start_dt_ya start_dt end_dt_ya end_dt
-- SQL code here
select '$',start_date- '1 year', start_date ....
SQL part

bteq <<SQL | grep '\\$'| read start_dt_ya start_dt end_dt_ya end_dt
-- SQL code here
select '$',start_date- '1 year', start_date ....
SQL
