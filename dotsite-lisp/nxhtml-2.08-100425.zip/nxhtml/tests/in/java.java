public class FirstProgram

{

     public static void main(String[] args)

     {

          System.out.println("Hey! you are going to compile and run your first Java program");

     }

}
