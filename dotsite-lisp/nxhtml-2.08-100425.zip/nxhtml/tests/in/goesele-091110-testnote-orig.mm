<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1257868981125" ID="ID_1727486195" MODIFIED="1257869002408" TEXT="Testnote">
<richcontent TYPE="NOTE"><html>
  <head>
    
  </head>
  <body>
    <p>
      A note
    </p>
  </body>
</html>
</richcontent>
</node>
</map>
